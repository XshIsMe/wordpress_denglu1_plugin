<?php

$options = get_option('denglu1_plugin_options');

$appId = $options['appId'];
$sUrl = $options['sUrl'];
$publicKey = $options['publicKey'];
$privateKey = $options['privateKey'];
